var CONFIG = {
    KEYWORDS: "jp.co.orangesoft.news_filter.config.keywords",
    URLS: "jp.co.orangesoft.news_filter.config.urls",
    BLOCK_COUNT: "jp.co.orangesoft.news_filter.block_count",
};

